public interface Increment {

	public void increment();
}
