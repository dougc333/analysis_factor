
I lost the .R files. 
Moved files to aws because github space was limited in 2010
Deleted AWS files after someone created 50k-80k charges on my AWS account

Appnotes still here, can recreate 
